package com.triggerbot;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import java.util.Random;

public class TriggerBot implements ClientModInitializer {
    private static KeyBinding toggleKey;
    private static boolean enabled = false;
    private static final Random random = new Random();
    private static final int MIN_DELAY = 40;
    private static final int MAX_DELAY = 90;
    private static final double RANGE = 3.2;
    private static final int FOV = 120;
    private static long lastAttack = 0;
    private static boolean wasSprinting = false;
    private static int sprintResetTicks = 0;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.triggerbot.toggle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_R, "category.triggerbot"
        ));
        
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.sendMessage(net.minecraft.text.Text.literal("§6[TriggerBot] §f" + (enabled ? "§aВКЛ" : "§cВЫКЛ")), true);
                }
            }
            if (enabled && client.player != null && client.world != null) {
                processTriggerBot(client);
            }
        });
    }

    private void processTriggerBot(MinecraftClient client) {
        long now = System.currentTimeMillis();
        int pingComp = 30; // Компенсация пинга
        int delay = MIN_DELAY + random.nextInt(MAX_DELAY - MIN_DELAY) + pingComp;
        if (now - lastAttack < delay) return;

        HitResult hitResult = client.crosshairTarget;
        if (hitResult == null || hitResult.getType() != HitResult.Type.ENTITY) return;
        
        EntityHitResult entityHit = (EntityHitResult) hitResult;
        Entity target = entityHit.getEntity();
        
        if (!(target instanceof LivingEntity)) return;
        if (target == client.player) return;
        if (((LivingEntity) target).getHealth() <= 0) return;
        if (target instanceof PlayerEntity && ((PlayerEntity) target).isCreative()) return;

        double distance = client.player.squaredDistanceTo(target);
        if (distance > RANGE * RANGE) return;

        Vec3d playerPos = client.player.getPos();
        Vec3d targetPos = target.getPos();
        Vec3d direction = targetPos.subtract(playerPos).normalize();
        Vec3d viewDir = client.player.getRotationVec(1.0F);
        double angle = Math.toDegrees(Math.acos(direction.dotProduct(viewDir)));
        
        if (angle > FOV / 2.0) return;

        // Легитный сброс спринта (имитация человека, обход античита)
        if (client.player.isSprinting() && sprintResetTicks == 0) {
            wasSprinting = true;
            client.player.setSprinting(false);
            client.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(client.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            sprintResetTicks = 3; // Задержка в 3 тика перед возвратом
        } else if (sprintResetTicks > 0) {
            sprintResetTicks--;
            if (sprintResetTicks == 0 && wasSprinting) {
                client.player.setSprinting(true);
                client.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(client.player, ClientCommandC2SPacket.Mode.START_SPRINTING));
                wasSprinting = false;
            }
        }

        // Античит: микро-джиттер прицела (0.2 - 0.5 градуса)
        float jitter = (random.nextFloat() - 0.5f) * 0.5f;
        client.player.setYaw(client.player.getYaw() + jitter);

        // Атака (комбо-крит сработает автоматически, если ты в прыжке)
        client.interactionManager.attackEntity(client.player, target);
        client.player.swingHand(client.player.getActiveHand());
        lastAttack = now;
    }
}