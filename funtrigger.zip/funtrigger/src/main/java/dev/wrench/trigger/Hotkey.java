package dev.wrench.trigger;

import org.lwjgl.glfw.GLFW;

/** Reads a key straight from GLFW (rising edge), so nothing is registered in the Controls menu. */
final class Hotkey {
    private boolean wasDown;

    boolean pollEdge(int keyCode) {
        long window = GLFW.glfwGetCurrentContext();
        if (window == 0L) {
            wasDown = false;
            return false;
        }
        boolean down = GLFW.glfwGetKey(window, keyCode) == GLFW.GLFW_PRESS;
        boolean edge = down && !wasDown;
        wasDown = down;
        return edge;
    }

    static boolean windowFocused() {
        long window = GLFW.glfwGetCurrentContext();
        return window != 0L && GLFW.glfwGetWindowAttrib(window, GLFW.GLFW_FOCUSED) == GLFW.GLFW_TRUE;
    }
}
