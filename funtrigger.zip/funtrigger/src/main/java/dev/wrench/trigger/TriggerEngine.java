package dev.wrench.trigger;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Per-tick state machine. START tick: decide (and begin a pre-hit sprint reset when needed).
 * END tick: revalidate everything and fire the vanilla attack path, same one a click uses.
 */
public final class TriggerEngine {
    private final TriggerConfig cfg;
    private final Hotkey hotkey = new Hotkey();
    private final SprintReset sprint = new SprintReset();

    private boolean enabled;
    private int targetId = Integer.MIN_VALUE;
    private int reactionLeft = -1;
    private int risingWaited;
    private boolean fireAtEnd;
    private boolean armedPre;
    private boolean postResetPending;

    public TriggerEngine(TriggerConfig cfg) {
        this.cfg = cfg;
    }

    public void onStartTick(MinecraftClient mc) {
        fireAtEnd = false;
        armedPre = false;

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null) {
            enabled = false;
            cycleReset(mc);
            return;
        }

        boolean focused = Hotkey.windowFocused();
        boolean edge = hotkey.pollEdge(cfg.toggleKey);
        if (edge && focused && mc.currentScreen == null) {
            enabled = !enabled;
            if (cfg.showToggleMessage) {
                p.sendMessage(Text.literal("Trigger: " + (enabled ? "ON" : "OFF")), true);
            }
        }

        sprint.onStartTick(mc, p);

        if (!enabled || !focused || mc.currentScreen != null
                || !p.isAlive() || p.isSpectator() || p.isUsingItem()) {
            cycleReset(mc);
            return;
        }

        if (postResetPending) {
            postResetPending = false;
            sprint.begin(mc, cfg.sprintResetTicks, true);
        }
        if (sprint.isActive()) {
            return; // a reset is running, no new cycle until forward is given back
        }

        LivingEntity target = currentTarget(mc, p);
        if (target == null) {
            targetId = Integer.MIN_VALUE;
            reactionLeft = -1;
            risingWaited = 0;
            return;
        }
        if (target.getId() != targetId) {
            targetId = target.getId();
            reactionLeft = -1;
            risingWaited = 0;
        }

        HitRules.PlayerState st = playerState(p);
        float cooldown = p.getAttackCooldownProgress(0.0f);
        HitRules.Verdict verdict = HitRules.decide(st, cooldown, cfg.minCooldown, risingWaited, cfg.critWaitTicks);
        if (verdict == HitRules.Verdict.WAIT) {
            if (cooldown >= cfg.minCooldown && HitRules.isRising(st)) {
                risingWaited++;
            }
            return;
        }

        if (reactionLeft < 0) {
            reactionLeft = rollReaction();
        }
        if (reactionLeft > 0) {
            reactionLeft--;
            return;
        }

        // Crit needs "not sprinting" on the server: release forward this tick, hit at the END of it.
        if (verdict == HitRules.Verdict.HIT_CRIT && p.isSprinting() && cfg.sprintReset
                && sprint.begin(mc, 1, true)) {
            armedPre = true;
            return;
        }
        fireAtEnd = true;
    }

    public void onEndTick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        boolean fire = fireAtEnd || armedPre;
        fireAtEnd = false;
        armedPre = false;
        if (p != null && mc.interactionManager != null && fire) {
            tryAttack(mc, p);
        }
        sprint.onEndTick(mc);
    }

    private void tryAttack(MinecraftClient mc, ClientPlayerEntity p) {
        if (!enabled || !Hotkey.windowFocused() || mc.currentScreen != null
                || !p.isAlive() || p.isUsingItem()) {
            return;
        }
        LivingEntity target = currentTarget(mc, p);
        if (target == null || target.getId() != targetId) {
            return;
        }
        HitRules.Verdict verdict = HitRules.decide(playerState(p), p.getAttackCooldownProgress(0.0f),
                cfg.minCooldown, risingWaited, cfg.critWaitTicks);
        if (verdict == HitRules.Verdict.WAIT) {
            return;
        }

        boolean wasSprinting = p.isSprinting();
        mc.interactionManager.attackEntity(p, target);
        p.swingHand(Hand.MAIN_HAND);

        reactionLeft = -1;
        risingWaited = 0;
        if (cfg.sprintReset && verdict == HitRules.Verdict.HIT_COMBO && wasSprinting) {
            postResetPending = true; // W-tap after a sprint hit, sprint comes back afterwards
        }
    }

    private LivingEntity currentTarget(MinecraftClient mc, ClientPlayerEntity p) {
        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY) {
            return null;
        }
        Entity e = ((EntityHitResult) hit).getEntity();
        if (!(e instanceof LivingEntity living) || living == p) {
            return null;
        }
        if (!living.isAlive() || living.isSpectator() || !living.isAttackable()) {
            return null;
        }
        boolean isPlayer = living instanceof PlayerEntity;
        if (isPlayer ? !cfg.targetPlayers : !cfg.targetOtherLiving) {
            return null;
        }
        if (cfg.ignoreTeammates && p.isTeammate(living)) {
            return null;
        }
        if (cfg.skipBlockingTargets && living.isBlocking()) {
            return null;
        }
        if (cfg.ignoreInvisible && living.isInvisible()) {
            return null;
        }
        return living;
    }

    private static HitRules.PlayerState playerState(ClientPlayerEntity p) {
        return new HitRules.PlayerState(
                p.isOnGround(),
                p.fallDistance,
                p.isClimbing(),
                p.isTouchingWater(),
                p.hasStatusEffect(StatusEffects.BLINDNESS),
                p.hasVehicle());
    }

    private int rollReaction() {
        int lo = cfg.reactionMinTicks;
        int hi = cfg.reactionMaxTicks;
        return lo >= hi ? lo : ThreadLocalRandom.current().nextInt(lo, hi + 1);
    }

    private void cycleReset(MinecraftClient mc) {
        targetId = Integer.MIN_VALUE;
        reactionLeft = -1;
        risingWaited = 0;
        fireAtEnd = false;
        armedPre = false;
        postResetPending = false;
        sprint.abort(mc);
    }
}
