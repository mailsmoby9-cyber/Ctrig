package dev.wrench.trigger;

import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/** Plain .properties config. Every value is clamped; bad values fall back to defaults. */
public final class TriggerConfig {
    public final int toggleKey;
    public final float minCooldown;
    public final int critWaitTicks;
    public final int reactionMinTicks;
    public final int reactionMaxTicks;
    public final boolean sprintReset;
    public final int sprintResetTicks;
    public final boolean targetPlayers;
    public final boolean targetOtherLiving;
    public final boolean ignoreTeammates;
    public final boolean skipBlockingTargets;
    public final boolean ignoreInvisible;
    public final boolean showToggleMessage;

    private static final String DEFAULT_TEXT = """
            # Trigger settings. Values are clamped on load; bad values fall back to defaults.
            # GLFW key code of the on/off key (82 = R). Read directly, not a Minecraft keybind.
            toggleKey=82
            # Minimum attack-cooldown progress before a hit (0.0-1.0). UNCALIBRATED.
            minCooldown=0.92
            # Max ticks to wait for the fall phase of a jump before hitting as a normal combo hit. UNCALIBRATED.
            critWaitTicks=10
            # Reaction delay in ticks, rolled uniformly in [min,max] per engagement. UNCALIBRATED.
            reactionMinTicks=0
            reactionMaxTicks=1
            # Release forward for a tick around hits so sprint stops and restarts like a manual W-tap.
            sprintReset=true
            # Ticks forward stays released after a ground (combo) hit. UNCALIBRATED.
            sprintResetTicks=1
            targetPlayers=true
            targetOtherLiving=false
            ignoreTeammates=true
            skipBlockingTargets=true
            ignoreInvisible=false
            showToggleMessage=true
            """;

    private TriggerConfig(Properties p) {
        toggleKey = parseInt(p.getProperty("toggleKey"), 82, 32, 348);
        minCooldown = parseFloat(p.getProperty("minCooldown"), 0.92f, 0.0f, 1.0f);
        critWaitTicks = parseInt(p.getProperty("critWaitTicks"), 10, 0, 40);
        int rMin = parseInt(p.getProperty("reactionMinTicks"), 0, 0, 20);
        int rMax = parseInt(p.getProperty("reactionMaxTicks"), 1, 0, 20);
        reactionMinTicks = rMin;
        reactionMaxTicks = Math.max(rMin, rMax);
        sprintReset = parseBool(p.getProperty("sprintReset"), true);
        sprintResetTicks = parseInt(p.getProperty("sprintResetTicks"), 1, 1, 5);
        targetPlayers = parseBool(p.getProperty("targetPlayers"), true);
        targetOtherLiving = parseBool(p.getProperty("targetOtherLiving"), false);
        ignoreTeammates = parseBool(p.getProperty("ignoreTeammates"), true);
        skipBlockingTargets = parseBool(p.getProperty("skipBlockingTargets"), true);
        ignoreInvisible = parseBool(p.getProperty("ignoreInvisible"), false);
        showToggleMessage = parseBool(p.getProperty("showToggleMessage"), true);
    }

    public static TriggerConfig loadOrCreate(Path file, Logger log) {
        Properties props = new Properties();
        if (Files.isRegularFile(file)) {
            try (InputStream in = Files.newInputStream(file)) {
                props.load(in);
            } catch (IOException | IllegalArgumentException e) {
                log.warn("Config read failed, using defaults: {}", e.toString());
                props.clear();
            }
        } else {
            try {
                Path parent = file.getParent();
                if (parent != null) {
                    Files.createDirectories(parent);
                }
                Files.writeString(file, DEFAULT_TEXT);
            } catch (IOException e) {
                log.warn("Could not write default config: {}", e.toString());
            }
        }
        return new TriggerConfig(props);
    }

    static int parseInt(String raw, int def, int min, int max) {
        if (raw == null) {
            return def;
        }
        try {
            int v = Integer.parseInt(raw.trim());
            return Math.min(max, Math.max(min, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static float parseFloat(String raw, float def, float min, float max) {
        if (raw == null) {
            return def;
        }
        try {
            float v = Float.parseFloat(raw.trim());
            if (!Float.isFinite(v)) {
                return def;
            }
            return Math.min(max, Math.max(min, v));
        } catch (NumberFormatException e) {
            return def;
        }
    }

    static boolean parseBool(String raw, boolean def) {
        if (raw == null) {
            return def;
        }
        String s = raw.trim().toLowerCase(Locale.ROOT);
        if (s.equals("true")) {
            return true;
        }
        if (s.equals("false")) {
            return false;
        }
        return def;
    }
}
