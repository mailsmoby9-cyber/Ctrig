package dev.wrench.trigger;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.effect.StatusEffects;
import org.lwjgl.glfw.GLFW;

/**
 * Manual-style W-tap: the forward key is released for N player ticks and then given back,
 * then sprint is restored. The game itself produces the stop/start sprint packets.
 * Order of calls per tick: onStartTick -> begin (START) -> onEndTick (END).
 */
final class SprintReset {
    private boolean active;
    private int ticksLeft;
    private boolean restoreAfter;
    private boolean restorePending;

    boolean isActive() {
        return active;
    }

    /** Releases forward. Returns false (and does nothing) if forward is not held. */
    boolean begin(MinecraftClient mc, int ticks, boolean restoreSprint) {
        if (active) {
            return false;
        }
        KeyBinding forward = mc.options.forwardKey;
        if (!forward.isPressed()) {
            return false;
        }
        forward.setPressed(false);
        active = true;
        ticksLeft = Math.max(1, ticks);
        restoreAfter = restoreSprint;
        return true;
    }

    /** Called at the start of a tick, before the player ticks. */
    void onStartTick(MinecraftClient mc, ClientPlayerEntity player) {
        if (!restorePending) {
            return;
        }
        restorePending = false;
        if (forwardPhysicallyDown(mc) && canSprint(player)) {
            player.setSprinting(true);
        }
    }

    /** Called at the end of a tick, after the player ticked (and after a hit, if any). */
    void onEndTick(MinecraftClient mc) {
        if (!active) {
            return;
        }
        ticksLeft--;
        if (ticksLeft <= 0) {
            finish(mc, restoreAfter);
        }
    }

    void abort(MinecraftClient mc) {
        if (active) {
            finish(mc, false);
        }
        restorePending = false;
    }

    private void finish(MinecraftClient mc, boolean restoreSprint) {
        active = false;
        mc.options.forwardKey.setPressed(forwardPhysicallyDown(mc));
        restorePending = restoreSprint;
    }

    /** True physical state of the forward key; falls back to "held" (we only start when it was held). */
    private static boolean forwardPhysicallyDown(MinecraftClient mc) {
        long window = GLFW.glfwGetCurrentContext();
        if (window == 0L) {
            return false;
        }
        try {
            String translationKey = mc.options.forwardKey.getBoundKeyTranslationKey();
            if (!translationKey.startsWith("key.keyboard.")) {
                return true;
            }
            int code = InputUtil.fromTranslationKey(translationKey).getCode();
            return GLFW.glfwGetKey(window, code) == GLFW.GLFW_PRESS;
        } catch (RuntimeException e) {
            return true;
        }
    }

    private static boolean canSprint(ClientPlayerEntity p) {
        return !p.isSneaking()
                && !p.isUsingItem()
                && !p.hasVehicle()
                && !p.hasStatusEffect(StatusEffects.BLINDNESS)
                && p.getHungerManager().getFoodLevel() > 6;
    }
}
