package dev.wrench.trigger;

/** Pure decision rules, no Minecraft types, checkable without the game. */
public final class HitRules {
    private HitRules() {}

    public enum Verdict { WAIT, HIT_CRIT, HIT_COMBO }

    public record PlayerState(boolean onGround, double fallDistance, boolean climbing,
                              boolean inWater, boolean blind, boolean riding) {
        public boolean critBlocked() {
            return climbing || inWater || blind || riding;
        }
    }

    public static boolean isFalling(PlayerState s) {
        return Double.isFinite(s.fallDistance()) && s.fallDistance() > 0.0;
    }

    /** Airborne, crit is possible in principle, but the fall phase has not started yet. */
    public static boolean isRising(PlayerState s) {
        return !s.onGround() && !s.critBlocked() && !isFalling(s);
    }

    /**
     * One mode for crit and combo:
     * grounded or crit-blocked -> combo hit; falling -> crit hit;
     * rising -> wait for the fall, but at most critWaitTicks, then hit as combo.
     */
    public static Verdict decide(PlayerState s, float cooldown, float minCooldown,
                                 int risingWaited, int critWaitTicks) {
        if (!(cooldown >= minCooldown)) {
            return Verdict.WAIT; // also catches NaN
        }
        if (s.onGround() || s.critBlocked()) {
            return Verdict.HIT_COMBO;
        }
        if (isFalling(s)) {
            return Verdict.HIT_CRIT;
        }
        return risingWaited >= critWaitTicks ? Verdict.HIT_COMBO : Verdict.WAIT;
    }
}
