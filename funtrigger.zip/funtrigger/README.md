# Trigger (Fabric 1.21.11, client)

Один режим крит+комбо. Вкл/выкл: R (читается напрямую через GLFW, в «Управлении» не появляется).
Настройки: `config/funtrigger.properties` (создаётся при первом запуске).

## Сборка на телефоне через GitHub
1. Новый репозиторий.
2. Add file -> Create new file, имя `.github/workflows/build.yml`, вставить содержимое `build.yml`, Commit.
3. Add file -> Upload files, загрузить `funtrigger.zip` НЕ распаковывая, Commit.
4. Вкладка Actions -> последний запуск -> Artifacts -> `funtrigger-jar`. Внутри .jar для папки mods.

Нужны: Fabric Loader 0.18.1+ и Fabric API для 1.21.11.

## Если сборка упала
Первые строки ошибки из лога Actions (красный шаг Build) — то, что нужно для правки.
Имена из Yarn, которые не проверялись сборкой: KeyBinding.setPressed / getBoundKeyTranslationKey,
InputUtil.fromTranslationKey, Entity.fallDistance, PlayerEntity.getAttackCooldownProgress,
MinecraftClient.crosshairTarget, ClientPlayerInteractionManager.attackEntity.
